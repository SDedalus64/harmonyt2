module.exports = async function (context, req) {
  const text = req.body && req.body.text;
  if (!text) {
    context.res = {
      status: 400,
      body: { error: "Missing 'text' in request body." }
    };
    return;
  }

  // Simple summary logic (placeholder)
  const summary = text.length > 100 ? text.slice(0, 100) + "..." : text;

  context.res = {
    status: 200,
    body: { summary }
  };
};
