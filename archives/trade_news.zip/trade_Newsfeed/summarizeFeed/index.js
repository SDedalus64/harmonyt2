const fetch = require("node-fetch");

module.exports = async function (context, req) {
  context.log("summarizeFeed function triggered");

  const prompt = req.body?.prompt || "Summarize recent trade activity.";
  const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
  const key = process.env.AZURE_OPENAI_KEY;
  const deployment = process.env.AZURE_OPENAI_DEPLOYMENT;

  try {
    const response = await fetch(`${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=2023-07-01-preview`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-key": key
      },
      body: JSON.stringify({
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7
      })
    });

    const data = await response.json();
    context.res = {
      status: 200,
      body: data.choices?.[0]?.message?.content || "No summary returned"
    };
  } catch (err) {
    context.res = {
      status: 500,
      body: "Failed to fetch from OpenAI: " + err.message
    };
  }
};